package mocking

type DoStuffer interface {
	DoStuff(input string) error
}
