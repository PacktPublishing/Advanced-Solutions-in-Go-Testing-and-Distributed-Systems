mockgen -destination internal/mocks.go -package internal github.com/agtorre/go-solutions/section1/mockgen GetSetter
