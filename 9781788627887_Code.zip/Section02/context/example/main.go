package main

import "github.com/agtorre/go-solutions/section2/context"

func main() {
	context.Exec()
}
